import { Router, Request, Response } from 'express';
import crypto from 'crypto';
import { pool } from '../database';
import { body, validationResult } from 'express-validator';
import nodemailer from 'nodemailer';

const router = Router();

// Email transporter dengan App Password Google
const createEmailTransporter = () => {
    const emailUser = process.env.EMAIL_USER;
    const emailPass = process.env.EMAIL_APP_PASSWORD;
    
    if (!emailUser || !emailPass) {
        console.error('Email credentials not configured in .env');
        return null;
    }
    
    return nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        secure: false,
        requireTLS: true,
        auth: {
            user: emailUser,
            pass: emailPass
        },
        tls: {
            rejectUnauthorized: false
        }
    });
};

const transporter = createEmailTransporter();

// Helper function untuk generate kode 6 digit
const generateCode = (): string => {
    return Math.floor(100000 + Math.random() * 900000).toString();
};

// Fungsi untuk mengirim email
const sendEmail = async (to: string, subject: string, htmlContent: string): Promise<boolean> => {
    if (!transporter) {
        console.error('Email transporter not initialized');
        return false;
    }
    
    try {
        const mailOptions = {
            from: `"SA:MP UCP Panel" <${process.env.EMAIL_USER}>`,
            to: to,
            subject: subject,
            html: htmlContent
        };
        
        const info = await transporter.sendMail(mailOptions);
        console.log('Email sent:', info.messageId);
        return true;
    } catch (error) {
        console.error('Error sending email:', error);
        return false;
    }
};

// Template email untuk login code
const loginEmailTemplate = (username: string, loginCode: string, expiryTime: string): string => {
    return `
        <div style="font-family: 'Inter', Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #ffffff;">
            <div style="background: #000000; padding: 30px; text-align: center;">
                <h1 style="color: #ffffff; margin: 0; font-size: 24px; font-weight: 600;">SA:MP UCP PANEL</h1>
            </div>
            
            <div style="padding: 40px;">
                <h2 style="color: #333333; margin-bottom: 20px; font-size: 20px; font-weight: 600;">
                    Login Verification Code
                </h2>
                
                <p style="color: #666666; line-height: 1.6; margin-bottom: 20px;">
                    Hello <strong>${username}</strong>,
                </p>
                
                <p style="color: #666666; line-height: 1.6; margin-bottom: 25px;">
                    Use the verification code below to login to your SA:MP UCP account.
                </p>
                
                <div style="background: #f8f9fa; border: 2px solid #000000; border-radius: 8px; padding: 30px; text-align: center; margin: 30px 0;">
                    <div style="font-size: 36px; font-weight: 700; letter-spacing: 10px; color: #000000; margin-bottom: 15px; font-family: monospace;">
                        ${loginCode}
                    </div>
                    <div style="font-size: 14px; color: #666666;">Enter this code on the login page</div>
                </div>
                
                <div style="background: #f8f9fa; border-left: 4px solid #000000; padding: 15px; margin: 20px 0;">
                    <p style="margin: 0; color: #666666;">
                        <strong>Important:</strong> This code will expire at <strong>${expiryTime}</strong> (15 minutes from now).
                        Do not share this code with anyone.
                    </p>
                </div>
                
                <p style="color: #666666; line-height: 1.6; font-size: 14px; margin-top: 30px;">
                    If you didn't request this code, please ignore this email or contact support immediately.
                </p>
            </div>
            
            <div style="background: #f8f9fa; padding: 20px; text-align: center; border-top: 1px solid #eeeeee; font-size: 12px; color: #999999;">
                <p style="margin: 0;">
                    This is an automated message from SA:MP User Control Panel.<br>
                    Please do not reply to this email.
                </p>
                <p style="margin: 10px 0 0 0;">
                    SA:MP UCP Panel &copy; ${new Date().getFullYear()}
                </p>
            </div>
        </div>
    `;
};

// Template email untuk register success (VerifyCode untuk game)
const registerSuccessEmailTemplate = (username: string, verifyCode: string, email: string): string => {
    return `
        <div style="font-family: 'Inter', Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #ffffff;">
            <div style="background: #000000; padding: 30px; text-align: center;">
                <h1 style="color: #ffffff; margin: 0; font-size: 24px; font-weight: 600;">SA:MP UCP PANEL</h1>
            </div>
            
            <div style="padding: 40px;">
                <h2 style="color: #333333; margin-bottom: 20px; font-size: 20px; font-weight: 600;">
                    Registration Successful!
                </h2>
                
                <div style="background: #f8f9fa; border-left: 4px solid #000000; padding: 15px; margin: 20px 0;">
                    <p style="margin: 0; color: #666666;">
                        Welcome to SA:MP UCP Panel, <strong>${username}</strong>! 
                        Your account has been successfully created.
                    </p>
                </div>
                
                <div style="background: #f8f9fa; border: 2px solid #000000; border-radius: 8px; padding: 30px; text-align: center; margin: 30px 0;">
                    <h3 style="color: #333333; margin-bottom: 15px; font-size: 18px; font-weight: 600;">
                        In-Game Verification Code
                    </h3>
                    <div style="font-size: 36px; font-weight: 700; letter-spacing: 10px; color: #000000; margin-bottom: 15px; font-family: monospace;">
                        ${verifyCode}
                    </div>
                    <div style="font-size: 14px; color: #666666;">Use this code in-game to verify your account</div>
                </div>
                
                <div style="background: #f5f5f5; padding: 20px; border-radius: 8px; margin: 30px 0;">
                    <h3 style="color: #333333; margin-bottom: 15px; font-size: 16px; font-weight: 600;">Account Information:</h3>
                    <table style="width: 100%; color: #666666; font-size: 14px;">
                        <tr>
                            <td style="padding: 8px 0; width: 120px;"><strong>Username:</strong></td>
                            <td>${username}</td>
                        </tr>
                        <tr>
                            <td style="padding: 8px 0;"><strong>Email:</strong></td>
                            <td>${email}</td>
                        </tr>
                        <tr>
                            <td style="padding: 8px 0;"><strong>Status:</strong></td>
                            <td><span style="color: #28a745; font-weight: 600;">Verified ✓</span></td>
                        </tr>
                    </table>
                </div>
                
                <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 30px 0;">
                    <h3 style="color: #333333; margin-bottom: 15px; font-size: 16px; font-weight: 600;">Next Steps:</h3>
                    <ol style="color: #666666; line-height: 1.6; padding-left: 20px;">
                        <li>Save your in-game verification code above</li>
                        <li>Use the code in SA:MP server to complete verification</li>
                        <li>You can now login to the website using your email</li>
                    </ol>
                </div>
                
                <p style="color: #666666; line-height: 1.6; font-size: 14px;">
                    <strong>Note:</strong> This in-game verification code is permanent for your account.
                    Keep it safe and do not share with anyone.
                </p>
            </div>
            
            <div style="background: #f8f9fa; padding: 20px; text-align: center; border-top: 1px solid #eeeeee; font-size: 12px; color: #999999;">
                <p style="margin: 0;">
                    This is an automated message from SA:MP User Control Panel.<br>
                    Please do not reply to this email.
                </p>
                <p style="margin: 10px 0 0 0;">
                    SA:MP UCP Panel &copy; ${new Date().getFullYear()}
                </p>
            </div>
        </div>
    `;
};

// ============ ROUTES ============

// Login Page
router.get('/login', (req: Request, res: Response) => {
    if ((req.session as any).user) {
        return res.redirect('/dashboard');
    }
    res.render('login', { 
        title: 'Login'
    });
});

// Login Code Page
router.get('/login-code', (req: Request, res: Response) => {
    if ((req.session as any).user) {
        return res.redirect('/dashboard');
    }
    const email = (req.session as any).loginEmail;
    if (!email) {
        return res.redirect('/login');
    }
    res.render('login-code', { 
        title: 'Enter Verification Code',
        email: email
    });
});

// Register Page
router.get('/register', (req: Request, res: Response) => {
    if ((req.session as any).user) {
        return res.redirect('/dashboard');
    }
    res.render('register', { title: 'Register' });
});

// ============ LOGIN FLOW ============

// Step 1: Request Login Code via Email
router.post('/request-login-code', [
    body('email').notEmpty().withMessage('Email is required').isEmail()
], async (req: Request, res: Response) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        req.flash('error_msg', errors.array()[0].msg);
        return res.redirect('/login');
    }

    const { email } = req.body;

    try {
        // Check if email exists
        const [rows]: any = await pool.execute(
            'SELECT * FROM accounts WHERE Email = ?',
            [email]
        );

        if (rows.length === 0) {
            req.flash('error_msg', 'Email not registered');
            return res.redirect('/login');
        }

        const user = rows[0];

        // Generate 6-digit login code
        const loginCode = generateCode();
        const codeExpiry = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes
        const expiryTime = codeExpiry.toLocaleTimeString([], { 
            hour: '2-digit', 
            minute: '2-digit',
            hour12: true 
        });

        // Save login code to database
        await pool.execute(
            'UPDATE accounts SET LoginCode = ?, CodeExpiry = ? WHERE Email = ?',
            [loginCode, codeExpiry, email]
        );

        // Send login code email
        const emailSent = await sendEmail(
            email,
            'SA:MP UCP - Login Verification Code',
            loginEmailTemplate(user.Username, loginCode, expiryTime)
        );

        if (!emailSent) {
            req.flash('error_msg', 'Failed to send verification code. Please try again later.');
            return res.redirect('/login');
        }

        // Store email in session for verification step
        (req.session as any).loginEmail = email;

        req.flash('success_msg', 'Login code has been sent to your email!');
        res.redirect('/login-code');
    } catch (error) {
        console.error('Login code request error:', error);
        req.flash('error_msg', 'An error occurred. Please try again.');
        res.redirect('/login');
    }
});

// Step 2: Verify Login Code
router.post('/verify-login-code', [
    body('code').notEmpty().withMessage('Verification code is required').isLength({ min: 6, max: 6 })
], async (req: Request, res: Response) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        req.flash('error_msg', errors.array()[0].msg);
        return res.redirect('/login-code');
    }

    const { code } = req.body;
    const email = (req.session as any).loginEmail;

    if (!email) {
        req.flash('error_msg', 'Session expired. Please try again.');
        return res.redirect('/login');
    }

    try {
        // Check login code
        const [rows]: any = await pool.execute(
            'SELECT * FROM accounts WHERE Email = ? AND LoginCode = ?',
            [email, code]
        );

        if (rows.length === 0) {
            req.flash('error_msg', 'Invalid verification code');
            return res.redirect('/login-code');
        }

        const user = rows[0];
        
        // Check if code is expired
        if (user.CodeExpiry) {
            const expiryDate = new Date(user.CodeExpiry);
            if (expiryDate < new Date()) {
                req.flash('error_msg', 'Verification code has expired');
                return res.redirect('/login');
            }
        }

        // Clear login code
        await pool.execute(
            'UPDATE accounts SET LoginCode = NULL, CodeExpiry = NULL WHERE Email = ?',
            [email]
        );

        // Update last login
        await pool.execute(
            'UPDATE accounts SET LastLogin = CURRENT_TIMESTAMP WHERE Email = ?',
            [email]
        );

        // Set session
        (req.session as any).user = {
            id: user.ID,
            username: user.Username,
            email: user.Email,
            phone: user.PhoneNumber,
            verifyCode: user.VerifyCode
        };

        // Clear login session data
        delete (req.session as any).loginEmail;

        res.redirect('/dashboard');
    } catch (error) {
        console.error('Login verification error:', error);
        req.flash('error_msg', 'An error occurred during verification');
        res.redirect('/login-code');
    }
});

// ============ REGISTER FLOW ============

// Register Handler (Tanpa verifikasi website, langsung verified)
router.post('/register', [
    body('username')
        .notEmpty().withMessage('Username is required')
        .isLength({ min: 3, max: 24 }).withMessage('Username must be 3-24 characters')
        .matches(/^[a-zA-Z0-9_]+$/).withMessage('Username can only contain letters, numbers, and underscores'),
    body('email')
        .notEmpty().withMessage('Email is required')
        .isEmail().withMessage('Invalid email format'),
    body('phone')
        .notEmpty().withMessage('Phone number is required')
        .matches(/^[0-9+\-\s]+$/).withMessage('Invalid phone number')
], async (req: Request, res: Response) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        req.flash('error_msg', errors.array()[0].msg);
        return res.redirect('/register');
    }

    const { username, email, phone } = req.body;

    try {
        // Check if username exists
        const [usernameRows]: any = await pool.execute(
            'SELECT Username FROM accounts WHERE Username = ?',
            [username]
        );

        if (usernameRows.length > 0) {
            req.flash('error_msg', 'Username already exists');
            return res.redirect('/register');
        }

        // Check if email exists
        const [emailRows]: any = await pool.execute(
            'SELECT Email FROM accounts WHERE Email = ?',
            [email]
        );

        if (emailRows.length > 0) {
            req.flash('error_msg', 'Email already registered');
            return res.redirect('/register');
        }

        // Check if phone exists
        const [phoneRows]: any = await pool.execute(
            'SELECT PhoneNumber FROM accounts WHERE PhoneNumber = ?',
            [phone]
        );

        if (phoneRows.length > 0) {
            req.flash('error_msg', 'Phone number already registered');
            return res.redirect('/register');
        }

        // Generate verification code untuk game
        const verifyCode = generateCode();

        // Insert user dengan status langsung verified
        const [result]: any = await pool.execute(
            `INSERT INTO accounts (Username, Email, PhoneNumber, VerifyCode, IsVerified, CreatedAt) 
             VALUES (?, ?, ?, ?, TRUE, CURRENT_TIMESTAMP)`,
            [username, email, phone, verifyCode]
        );

        const userId = result.insertId;

        // Kirim email dengan kode verifikasi untuk game
        const emailSent = await sendEmail(
            email,
            'SA:MP UCP - Registration Successful',
            registerSuccessEmailTemplate(username, verifyCode, email)
        );

        if (!emailSent) {
            console.warn('Failed to send registration email, but account created');
        }

        // Langsung login user setelah register
        (req.session as any).user = {
            id: userId,
            username: username,
            email: email,
            phone: phone,
            verifyCode: verifyCode
        };

        req.flash('success_msg', 'Registration successful! Welcome to SA:MP UCP Panel.');
        res.redirect('/dashboard');
    } catch (error) {
        console.error('Registration error:', error);
        req.flash('error_msg', 'An error occurred during registration');
        res.redirect('/register');
    }
});

// ============ LOGOUT ============

// Logout Handler
router.get('/logout', (req: Request, res: Response) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Logout error:', err);
        }
        res.redirect('/');
    });
});

// ============ API ENDPOINTS ============

// API untuk check username availability
router.get('/api/check-username/:username', async (req: Request, res: Response) => {
    try {
        const [rows]: any = await pool.execute(
            'SELECT Username FROM accounts WHERE Username = ?',
            [req.params.username]
        );
        
        res.json({ available: rows.length === 0 });
    } catch (error) {
        console.error('API error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// API untuk check email availability
router.get('/api/check-email/:email', async (req: Request, res: Response) => {
    try {
        const [rows]: any = await pool.execute(
            'SELECT Email FROM accounts WHERE Email = ?',
            [req.params.email]
        );
        
        res.json({ available: rows.length === 0 });
    } catch (error) {
        console.error('API error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// API untuk check phone availability
router.get('/api/check-phone/:phone', async (req: Request, res: Response) => {
    try {
        const [rows]: any = await pool.execute(
            'SELECT PhoneNumber FROM accounts WHERE PhoneNumber = ?',
            [req.params.phone]
        );
        
        res.json({ available: rows.length === 0 });
    } catch (error) {
        console.error('API error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

export default router;